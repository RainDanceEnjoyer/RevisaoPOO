﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Polimorfismo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Imposto estagiarioObj = new Estagiario();
            estagiarioObj.valeAlimentacao(1000);
            estagiarioObj.valeTransporte(1000);
            //se houver metodos no Estagiario() que sobrescrevem o imposto, o mesmo sera sobrescrito, se não, não se altera
            Imposto atendenteObj = new Atendente();
            atendenteObj.valeAlimentacao(2000);
            atendenteObj.valeTransporte(2000);
            //se houver metodos no Atendente() que sobrescrevem o imposto, o mesmo sera sobrescrito, se não, não se altera
            Imposto gerenteObj = new Gerente();
            gerenteObj.valeAlimentacao(5000);
            gerenteObj.valeTransporte(5000);            
            //se houver metodos no Gerente() que sobrescrevem o imposto, o mesmo sera sobrescrito, se não, não se altera
        }
    }
}
