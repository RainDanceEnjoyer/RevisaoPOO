﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Polimorfismo
{
    internal class Gerente : Imposto //herança
    {
        public override void valeAlimentacao(double salario) //override
        {
            MessageBox.Show("Desconto padrão vale alimentação (gerente): R$" + (salario * 0.15));
        }
    }
}
