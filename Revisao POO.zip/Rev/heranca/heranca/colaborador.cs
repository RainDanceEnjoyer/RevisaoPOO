﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace heranca
{
    //colaborador herda de pessoa
    internal class colaborador : Pessoa
    {
        //atributos privados para apenas colaborador poder ter acesso
        private double salario;

        //construtor
        public colaborador(string _nome, string _email, double salario, int _id)
        {
            this._nome = _nome;
            this._email = _email;
            this._id = _id;
            this.salario = salario;

            Mensagem();
            MensagemColab();
        }
        private void MensagemColab()
        {
            MessageBox.Show("salario: " + salario);
        }
    }
}
