﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace thisRev
{
    internal class Pessoa
    {
        //atributo
        private string nome = "Gladstone"; //atributo de mesmo nome

        //construtor
        public Pessoa(string nome) //parâmetro de mesmo nome
        {
            MessageBox.Show(this.nome); //o this assegura que o C# vai 'puxar' o atributo, já que os dois tem o mesmo nome
            //sem o this, o nome "Miguel" seria o exibido
        }
    }
}
