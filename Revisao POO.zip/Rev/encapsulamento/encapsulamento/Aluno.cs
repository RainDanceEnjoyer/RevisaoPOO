﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace encapsulamento
{
    internal class Aluno
    {
        private double nota1, nota2;


        private double Media()
        {
            return (nota1 + nota2) / 2;
        }

        public void message()
        {
            Console.WriteLine("diga a primeira nota");
            nota1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("diga a segunda nota");
            nota2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Média: " + Media());
        }
    }
}


/*
    todos os métodos privados ficam 'escondidos' dentro do 
    Aluno.cs e não são acessíveis por nenhum outro arquivo .cs
 */