﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetSet
{
    internal class GetSet
    {
        /*
         serve para conseguir transitar informações encapsuladas (privadas)
         set = envia informação para um atributo 
         get = o atributo recebe uma informação
        */


        private string _name;

        //Get e Set
        public string Name { get { return _name; } set { _name = value; } }


    }
}
