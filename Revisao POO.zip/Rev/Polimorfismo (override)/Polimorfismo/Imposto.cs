﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Polimorfismo
{
    internal class Imposto
    {
        public virtual void valeAlimentacao(double salario) //virtual
        {
            MessageBox.Show("Desconto padrão vale alimentação: R$"+(salario * 0.1));
        }
        public void valeTransporte(double salario)
        {
            MessageBox.Show("Desconto padrão valetransporte: R$" + (salario * 0.06));
        }

    }
}
