﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace construtor
{
    internal class Pessoa
    {
        //todo construtor de um objeto é público
        public Pessoa() 
        {
            MessageBox.Show("Contrutor Executado");
        }

        public Pessoa(int id) //exemplo de polimorfismo (sobrecarga)
        {
            MessageBox.Show($"id = {id}");
        }
    }
}
