﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace heranca
{
    //protected: essa classe e todas as classes derivadas dela tem acesso aos atributos protected
    internal class Pessoa
    {

        protected int _id;
        protected string _nome;
        protected string _email;

        protected void Mensagem()
        {
            MessageBox.Show("nome: " + _nome);
            MessageBox.Show("id: " + _id);
            MessageBox.Show("email: " + _email);
        }
    }
}
